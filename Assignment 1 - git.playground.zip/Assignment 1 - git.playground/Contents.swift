

//Swift Basics 1 – Assignments
//ONLINE COMPILER USED =  https://www.onlinegdb.com/online_swift_compiler


/*
Exercise 1
Declare a floating point variable that represents temperature and assign the current temperature to it. If you don't have a thermometer, guess the temperature. :-)

var numberTemp : Int


Then assign a different temperature to it. Pick one at random, it
doesn't matter.

Exercise 2
Declare a constant integer value that represents the number of
seconds in an hour and assign that number to it on the same line.
Then try to assign a different value to the constant. Why doesn't it
work?
Use int, # of seconds in a hour, add # of hours -> after working change later
Int = 25300
func secondsToHoursMinutesSeconds(_ seconds: Int) -> (Int, Int, Int) {
   return (seconds / 3600, (seconds % 3600) / 60, (seconds % 3600) % 60)
}


let (h,m,s) = secondsToHoursMinutesSeconds(27005)


func printSecondsToHoursMinutesSeconds(_ seconds: Int) {
 let (h, m, s) = secondsToHoursMinutesSeconds(seconds)
 print ("\(h) Hours, \(m) Minutes, \(s) Seconds")
}

·         Couldn’t print – its showing error

Exercise 3
Declare an integer variable with an explicit type annotation and then one without.

var stringName : String (explicit type)

Exercise 4
Declare a constant integer value that represents the number of wheels of a car.
Don't assign it a value on the same line. On the next line, assign a value to the constant. Why does this work?


let Car: String = "HONDA"
var number: Int

//Wheels = "Four"
number = 4


Exercise 5
Declare the constant π using the name π, which you can type by pressing alt-p.

let π = 3.14159

Exercise 6
Declare a variable using an emoji in the name.

var 😄 = "whatsup"
print(😄)

Exercise 7
Print a variable using the print() function.

print("friendlyWelcome")

Exercise 8
What is the maximum value that can be stored in an Int16? Write the code that prints the maximum value of the Int16 type.
What type is the constant pi in the example below? Why?
let pi = 3 + 0.141592654
·         maximum value for Int16 type – 32768
print("UInt16          \(UInt16.min)        \(UInt16.max)")


Exercise 9
What happens if you try the following code? Why?
let myNumber: UInt = -17

It shows error: negative integer '-17' overflows when stored into unsigned type 'UInt'

Exercise 10
What happens if you try the following code? Why?
let bigNumber: Int16 = 32767 + 1
it shows let bigNumber: Int16 = 32767 + 1

Exercise 11
Why does the following code not work? What do you need to add to it to make it work, if we absolutely want to store this value as an integer, i.e. 3, but we don't want to change the type of the
variables?
let pi = 3.141592654
let approximatePi: Int = pi
Ans: Printed below:
error: cannot convert value of type 'Double' to specified type 'Int'
let approximatePi: Int = pi
                        ^~
                        Int( )
Exercise 12
There are two types of comments. Single-line and multiline
comments. Write one of both.
//   single line comments
/*  */  multiline
comments


Exercise 13
In Swift multiline comments can be nested. Write a nested multiline comment.
if (b > c) {
    
     // Print statement 3
     print("200 is Greater")
 }

 // inner else statement
 else {
    
     // Print statement 4
     print("300 is Greater");
 }
·         error shown

Exercise 14
Write to sentences in one line.
if (myVar) return;

*/



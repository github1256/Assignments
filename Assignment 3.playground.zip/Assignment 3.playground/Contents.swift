/*
//Swift Basics 3 – Assignments

//USED XCODE FOR SYNTAX:

//1. Create a function to add two integers and returns an
integer value ?

import UIKit
 
func addNumbers(a: Int, b: Int) {
  var sum = a + b
  print("Sum:", sum)
}
 
addNumbers(a: 2, b: 3)

//OUTPUT:
//Sum: 5



//2. What Causes an Error in This Piece of Code? How Could
//You Fix It?
/*
let n1: Int = 1
let n2: Float = 2.0
let n3: Double = 3.34
var result = n1 + n2 + n3
*/
// below code - fixed from above
import UIKit
let n1: Int = 1
let n2: Float = 2.0
let n3: Double = 3.34
var result = Double(n1) + Double(n2) + n3
print(result)

//SOLUTION: 6.34


/*
3. What Does init() Do in Swift?
Swift is the process of preparing an instance of a class, structure, or enumeration for use. This process involves setting an initial value for each stored property on that instance and performing any other setup or initialization that is required before the new instance is ready for use.

4. What Are Protocols in Swift? Give an Example
Protocol is a blueprint of methods, properties, and other requirements that suit a particular task or piece of functionality. The protocol can then be adopted by a class, structure, or enumeration to provide an actual implementation of those requirements.
Protocols can be accessed as types in:
Function, method or initialize as a parameter or return type Constant, variable or property Arrays, dictionaries or other containers as items
Example :
*/
protocol Greet {

  // blueprint of a property
  var name: String { get }


  // blueprint of a method
  func message()
}
*/
//5.What Is the Double Question Mark Operator?
   // The nullish coalescing operator ( ?? ) is a logical operator that returns its right-hand side operand when its left-hand side operand is null or undefined , and otherwise returns its left-hand side operand.

//6.What Is the Guard Statement?
//Guard statement is a statement that is used to transfer program control out of a scope if one or more conditions aren't met.This allows us to implement checks into our code that prevents the current scope from continuing.

//7.What Are the Three Primary Collection Types in Swift?
Arrays, sets, and dictionaries

8.What’s the Difference Between Structures and Classes?
Structures are value types and classes are reference types.

9.What is Optional Chaining?
Optional chaining is a process for querying and calling properties, methods, and subscripts on an optional that might currently be nil.

10.What Is Optional Binding?
    Optional binding is a mechanism built into Swift to safely unwrap optionals.



11.What Is an In-Out Parameter in Swift? Give an example?
An inout parameter is a special type of parameter that can be modified/changed inside a function and the changes apply outside the function.
Example :-      */
import UIKit
func change(_ number: inout Int){
    number = 2
}
var number = 1
change(&number)
print(number)
 
 
SOLUTION:: 2
/*
12. Is It Possible to Give a Default Value to a Function
Parameter?

Yes, it's possible.

13.What Is Force Unwrapping? When Should You Use It?
Give an example?

Forced unwrapping is an action done on the normal Optionals. It is used when an individual is sure that the value isn't nill.
Example -                   */
import UIKit
var company:String? = "Apple"
print(company!)
 
//OUTPUT :
//Apple
 

14.What Does the Mutating Keyword Do? Give an example?

The mutating keyword is only required if you are changing any state contained within the struct.


Example :
import UIKit
struct MyStruct {
    var abc: String = "initial value"
 
    mutating func changeValue() {
        abc = "some other value"
   }
}

//15.What is a Deinitializer? How to Create One?
    //Deinitializer is called to deallocate the memory space before a class instance //deallocated. Using deinit keyword,  Deinitializer is created.

//Example :
// declare a class
class  Race {
  var laps: Int

  // define initializer
  init() {
    laps = 5
    print("Race Completed")
    print("Total laps:", laps)
  }

  // define deinitializer
  deinit {
    print("Memory Deallocated")
  }
}

// create an instance
var result: Race? = Race()

// deallocate object
result = nil
SOLUTION:
Race Completed
Total laps: 5
Memory Deallocated


/*
16.What is a Protocol in swift?
A protocol defines a blueprint of methods or properties that can then be adopted by classes (or any other types)
17.What’s the difference between a protocol and a class in
Swift?
     Objects can be created from classes, whereas protocols are just type definitions.

18.Can You Fix the Issue in this Code?
struct Apple {
func pick(apple: Apple?) {
  guard let apple = apple else {
    print(&quot;No apple found!&quot;)
  }
  print(apple)
}

*/
_____________________________________________
//Yes, code can be fixed and it is below:-

struct Apple {

var apple: String

}

func pick(apple: Apple?) {

  guard let apple = apple else {

    print(&quot;No apple found!&quot;)

  }

  print(apple)

}

//19. How to inherit multiple protocols in a same class? Give an
//Example?
 Multiple protocols can be listed, and are separated by commas:
struct SomeStructure: FirstProtocol, AnotherProtocol {
 
   // structure definition goes here
 
}

/* 20.How to append one array to another array in Swift?
    There are 3 ways to
First -  array mutable append(contentsOf:)
Second - with += operator
Third - regular +

var first = [&quot;John&quot;, &quot;Paul&quot;]
let second = [&quot;George&quot;, &quot;Ringo&quot;]
first.append(contentsOf: second)
___________
Improvised code below:
import UIKit
var first = ["&quot;John&quot;", "&quot;Paul&quot;"]
var second = ["&quot;George&quot;", "&quot;Ringo&quot;"]
            
first.append(contentsOf: second)
first += second
let third = first + sec
*/


